%----------------------------------------------------------------------%
%-------------Auteurs : Yong Eun KIM et Tanguy GBAHOUO-----------------%
%-Projet Analyse de données - Simulation du moteur de recherche Google-%
%--------------Année 2016-2017 - Université Paris-Sud------------------%
%----------------------------------------------------------------------%
%on va lire le répertoire pages_web contenant nos fichiers txt
%faisant office de sites web (bien faire attention à se placer sur le
%répertoire parent pour que le chemin relatif soit bien pris en compte
repertoire = 'pages_web';
cd(repertoire);
extension = '*.txt';
%On ne prend que les fichiers au format .txt
fichiers = dir(extension);
%fichiers est une structure contenant la liste des fichiers
%on compte le nombre de fichiers
nbr = numel(fichiers);
%on initialise la matrice de transition avec comme dimension carrée le
%nombre de fichiers présents
Mtransition = zeros(nbr);
%------------Construction de la matrice de transition--------------%
%Boucle #1 pour les fichiers
for i=1:nbr
    %on initialise un vecteur pour construire au fur et à mesure la matrice
    %de transition colonne par colonne
    vecteur = zeros(nbr,1);
    prefix = 'pointeurvers:';
    nom_fichier = fichiers(i).name;
    fprintf('Dans %s\n', nom_fichier);
    %On lit le fichier dans l'ordre du dossier
    text = fileread(nom_fichier);
    %Pour chaque fichier, on regarde s'il y a des pointeurs
    %Boucle #2 pour les pointeurs
    for j=1:nbr
        suffix = strcat('p',int2str(j));
        %on construit puis on recherche dans une chaîne de type
        %"pointeurvers:pj"
        str = strcat(prefix,suffix);
        fprintf('Je regarde le pointeur %s\n',str);
        res = strfind(text,str);
        %Si on trouve une correspondance, on ajoute 1 à la ligne
        %correspondante du vecteur.
        if(isempty(res) == 0)
            vecteur(j, 1) = 1;
        end
    end
    %La somme des éléments du vecteur donne le nombre de pointeurs
    %inclus dans le fichier courant
    sumVect = sum(vecteur);
    disp(vecteur);
    %On divise chaque élément (=1) du vecteur par la somme totale
    %(la somme de chaque colonne doit valoir 1)
    vecteurFinal(:, 1) = vecteur(:, 1)./sumVect;
    disp(vecteurFinal);
    %On ajoute le vecteurFinal à la colonne i de la matrice de transition
    Mtransition(:,i) = vecteurFinal(:, 1);
    %Pour éviter que les valeurs des vecteurs restent en mémoire en fin de
    %boucle, on fait un nettoyage
    clearvars vecteur vecteurFinal;
end
%------------Fin Construction de la matrice de transition-----------%
%affichage de la matrice de transition construite
disp(Mtransition);
%constante alpha défini par Google (cours)
a = 0.85;
%on a "nbr" sites
n = nbr;
%un = Matrice de "1" de même dimensions que Mtransition
un = ones(n);
%Calcul de la matrice de Google à partir de Mtransition, a, n et un (cours)
Google = a*Mtransition+((1-a)/n)*un;
%affichage
disp(Google);
%v = vecteur population initiale (les valeurs du vecteur sont normalisés)
%par exemple, les internautes commencent à partir du site n°2
v = zeros(1,nbr);
v(1,2) = 1;
%Initialisation de la matrice t qui va sauvegarder chaque vecteur
%population au bout de 100 pas de temps (temps suffisamment grand)
t = zeros(100, nbr);
%boucle pour calculer récursivement chaque vecteur population après chaque
%pas de temps
for i=1:100
    t(i,:) = v*Google;
    v = t(i,:);
end
%Graphique d'évolution des valeurs pour chaque état.
plot(t);
%On remarque qu'au bout d'environ 40 pas, les valeurs pour chaque état se
%stabilise (regarder le croisement des courbes)
%On déduit qu'il faut faire 40 pas (Google^40) pour trouver un vecteur
%population qui tend vers l'équilibre.
Google40 = Google^40;
%Au bout d'un temps long, chaque colonne de la matrice correspond au
%vecteur pi (les colonnes sont -pratiquement- égales), on peut donc prendre
%la première colonne.
%Chaque composante de pi correspond au PageRank de chaque site.
pi = Google40(:,1);
%On récupère les dimensions du vecteur avec m et n
[m, n] = size(pi);
%on va ajouter une colonne pageRank à la structure fichiers pour
%correspondre chaque page à son indice.
%----------------------------------------------------------------
%On initialise les valeurs de la colonne par 0
[fichiers(:).pageRank] = deal(0);
%On ajoute pour chaque ligne i de la colonne pageRank de fichiers la valeur
%de pi(i)
for i=1:m
    fichiers(i).pageRank = deal(pi(i));
end
%On invite l'utilisateur à saisir un mot à rechercher
message = 'Quel mot voulez-vous chercher ?';
%Le mot saisi est enregistré dans la variable recherche
recherche = input(message, 's');
%On initialise une structure pour sauvegarder le nom des pages contenant
%les mots recherchés, avec leur pageRank respectif
champ1 = 'name';
champ2 = 'pageRank';
pagesOK = struct(champ1, {}, champ2, {});
%On parcourt la structure fichiers
for i=1:numel(fichiers)
    %nom_fichier contient la valeur à l'indice i de la colonne "name"
    nom_fichier = fichiers(i).name;
    %lecture du fichier à l'indice i
    text = fileread(nom_fichier);
    %recherche de la valeur de la variable recherche dans le fichier
    res = strfind(text,recherche);
    %Si le résultat n'est pas vide (1=true & 0=False)
    if(isempty(res) == 0)
        %Ajout du nom du fichier et son pageRank si mot trouvé
        pagesOK(end+1) = struct(champ1, nom_fichier, champ2, fichiers(i).pageRank);
    end
    %On vide ces variables en fin de boucle pour être sûr de bien faire
    %l'opération
    clearvars nom_fichier text;
end
if(isempty(pagesOK) == 1)
    disp('Aucun résultat, retentez votre chance !');
end
%On va maintenant trier la structure pagesOK pour lister les pages par
%ordre décroissant de pageRank
fieldsOK = fieldnames(pagesOK);
%on convertit la structure en tableau
cellsOK = struct2cell(pagesOK);
sz = size(cellsOK);
%on convertit le tableau en matrice
cellsOK = reshape(cellsOK, sz(1), []);
%chaque ligne est mis en colonne (c'est la transposée via le raccourci "'")
cellsOK = cellsOK';
%on trie par ordre décroissant la colonne correspondant à pageRank
cellsOK = sortrows(cellsOK, -2);
%On revient vers le format tableau
cellsOK = reshape(cellsOK', sz);
%On revient au format structure
pagesOKtrie = cell2struct(cellsOK,fieldsOK,1);
%On affiche la structure triée par ordre décroissant de pageRank
for x=1:numel(pagesOKtrie)
    disp(pagesOKtrie(x));
end